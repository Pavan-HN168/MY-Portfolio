/**
 * Karunadu Tiffinbox - South Karnataka Meal Subscription Application
 * Core JavaScript logic: State management, Customer & Protected Owner Desk,
 * Real-world payment gateway simulator, and CSV export.
 */

// Application Data Stores (with LocalStorage fallback)
const DEFAULT_MENU = [
  {
    id: 1,
    name: "Davanagere Benne Dosa",
    region: "Central Karnataka",
    category: "breakfast",
    price: 95,
    description: "Crispy, fluffy fermented rice pancake roasted with pure white churned butter. Served with potato palya & spicy coconut chutney.",
    image: "https://images.unsplash.com/photo-1610192244261-3f33de3f55e4?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: true
  },
  {
    id: 2,
    name: "Mandya Ragi Mudde with Bassaru",
    region: "Old Mysore",
    category: "lunch",
    price: 130,
    description: "Wholesome finger-millet ball paired with traditional dill-greens dill saaru, palya, native kosambari & fresh curd.",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: true
  },
  {
    id: 3,
    name: "Mysore Bisi Bele Bath",
    region: "Mysuru Royal Kitchen",
    category: "lunch",
    price: 110,
    description: "Aromatic lentil and vegetable rice slow-cooked with 18 freshly pounded spices, cashews, and generous girimane ghee.",
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: false
  },
  {
    id: 4,
    name: "Baleele Akki Rotti & Yennegai",
    region: "North/Central Karnataka",
    category: "dinner",
    price: 115,
    description: "Hand-patted rice flatbreads infused with fresh coriander & dill, served with spicy stuffed brinjal curry (Badanekayi Yennegai).",
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: true
  },
  {
    id: 5,
    name: "Mangaluru Buns & Neer Dosa",
    region: "Coastal Karnataka",
    category: "breakfast",
    price: 85,
    description: "Mildly sweet banana puris & soft-as-dew paper thin Neer Dosas served with Kundapur vegetable sagu & roasted red chutney.",
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: false
  },
  {
    id: 6,
    name: "Kottige & Kayi Haalu (Jackfruit Leaf Idli)",
    region: "Malenadu Specialty",
    category: "breakfast",
    price: 105,
    description: "Steamed cylindrical rice batter wrapped in wild leaves, paired with cardamom spiced sweetened coconut milk.",
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: false
  },
  {
    id: 7,
    name: "Vangi Bath & Mosaru Bajji",
    region: "Bengaluru Traditional",
    category: "dinner",
    price: 100,
    description: "Spiced brinjal rice prepared with dry coconut masala, roasted peanuts, and served with cool cucumber pachadi.",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: false
  },
  {
    id: 8,
    name: "Bella Ragi Manni & Gasagase Payasa",
    region: "Traditional Dessert",
    category: "lunch",
    price: 75,
    description: "Natural organic jaggery and poppy seed pudding cooked in pure coconut milk with golden fried cashews.",
    image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?w=400&auto=format&fit=crop&q=80",
    available: true,
    special: false
  }
];

const DEFAULT_PLANS = [
  {
    id: "trial",
    name: "3-Day Trial Thali",
    duration: "3 Days",
    meals: 3,
    price: 349,
    perMeal: 116,
    badge: "Sample the taste",
    features: [
      "Any Breakfast or Lunch Oota",
      "Free door delivery (30 mins)",
      "Eco-friendly banana leaf box",
      "No commitment trial"
    ]
  },
  {
    id: "weekly",
    name: "6-Day Executive Box",
    duration: "Monday - Saturday",
    meals: 6,
    price: 699,
    perMeal: 116,
    badge: "Most popular for office",
    features: [
      "Breakfast + Midday Oota option",
      "1 meal free skip per week",
      "Free sweet every Wednesday",
      "Delivered in thermal brass tiffin"
    ]
  },
  {
    id: "monthly",
    name: "26-Day Grand Karunadu",
    duration: "1 Month (Mon - Sat)",
    meals: 26,
    price: 2899,
    perMeal: 111,
    badge: "Best Value • Save ₹600",
    features: [
      "Complete Rotational South Karnataka menu",
      "Unlimited meal pauses & carryovers",
      "Complimentary Gasagase Payasa on Fridays",
      "Dedicated kitchen supervisor support"
    ]
  }
];

const DEFAULT_SUBSCRIBERS = [
  { id: 101, name: "Dr. Subramanya M.", plan: "26-Day Grand Karunadu", address: "8th Cross, Malleshwaram, Bengaluru", slot: "Midday Oota (12:30 PM)", status: "Active" },
  { id: 102, name: "Pooja Hegde", plan: "6-Day Executive Box", address: "Indiranagar 100ft Road, Bengaluru", slot: "Breakfast (7:30 AM)", status: "Active" },
  { id: 103, name: "Venkatesh Prasad", plan: "26-Day Grand Karunadu", address: "Jayanagar 4th T Block, Bengaluru", slot: "Midday Oota (12:30 PM)", status: "Paused Today" },
  { id: 104, name: "Ananya Deshpande", plan: "3-Day Trial Thali", address: "Saraswathipuram, Mysuru", slot: "Night Dinner (7:45 PM)", status: "Active" },
  { id: 105, name: "Raghavendra Rao", plan: "26-Day Grand Karunadu", address: "Sugar Town Colony, Mandya", slot: "Midday Oota (12:30 PM)", status: "Active" }
];

// App State
let menuData = JSON.parse(localStorage.getItem('kt_menu')) || DEFAULT_MENU;
let planData = JSON.parse(localStorage.getItem('kt_plans')) || DEFAULT_PLANS;
let subscriberData = JSON.parse(localStorage.getItem('kt_subscribers')) || DEFAULT_SUBSCRIBERS;
let isOwnerLoggedIn = localStorage.getItem('kt_owner_auth') === 'true';
let currentSelectedPlan = null;
let currentPaymentMethod = 'upi';
let isMealPaused = false;

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  renderAuthNav();
  renderCustomerMenu('all');
  renderCustomerPlans();
  setupCategoryFilters();
  updateLiveClock();
  setInterval(updateLiveClock, 30000);

  if (isOwnerLoggedIn) {
    refreshOwnerDashboard();
  }
});

// Toggle Mobile Menu
function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  if (menu) {
    menu.classList.toggle('hidden');
  }
}

// Real-Time Clock
function updateLiveClock() {
  const clockEl = document.getElementById('liveTime');
  if (clockEl) {
    const now = new Date();
    clockEl.innerText = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) + " IST";
  }
}

// Auth Header Navigation rendering
function renderAuthNav() {
  const container = document.getElementById('authNavContainer');
  if (!container) return;

  if (isOwnerLoggedIn) {
    container.innerHTML = `
      <div class="flex items-center gap-2">
        <button onclick="toggleView('owner')" class="px-3.5 py-2 bg-amber-800 text-white rounded-xl text-xs font-bold shadow-sm hover:bg-amber-900 transition flex items-center gap-1.5">
          <i class="fa-solid fa-gauge"></i>
          <span>Owner Desk</span>
        </button>
        <button onclick="toggleView('customer')" class="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition">
          Customer View
        </button>
        <button onclick="logoutOwner()" title="Logout Owner" class="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition">
          <i class="fa-solid fa-power-off"></i>
        </button>
      </div>
    `;
  } else {
    container.innerHTML = `
      <button onclick="promptOwnerLogin()" class="px-3.5 py-2 bg-amber-100/90 hover:bg-amber-200 text-amber-900 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-amber-300">
        <i class="fa-solid fa-lock text-[10px]"></i>
        <span>Owner Login</span>
      </button>
    `;
  }
}

// Switching Between Customer View & Owner Desk
function toggleView(view) {
  const customerView = document.getElementById('customerPortal');
  const ownerView = document.getElementById('ownerPortal');

  if (view === 'owner') {
    if (!isOwnerLoggedIn) {
      promptOwnerLogin();
      return;
    }
    customerView.classList.add('hidden');
    ownerView.classList.remove('hidden');
    refreshOwnerDashboard();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else {
    ownerView.classList.add('hidden');
    customerView.classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

// Modal Handlers
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('hidden');
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('hidden');
}

// OWNER LOGIN & AUTHENTICATION
function promptOwnerLogin() {
  document.getElementById('loginErrorMsg').classList.add('hidden');
  openModal('ownerLoginModal');
}

function handleOwnerLogin(event) {
  event.preventDefault();
  const passcode = document.getElementById('ownerPasscode').value.trim();

  // Secure Passcode validation (Owner Passcode: admin123)
  if (passcode === 'admin123') {
    isOwnerLoggedIn = true;
    localStorage.setItem('kt_owner_auth', 'true');
    closeModal('ownerLoginModal');
    renderAuthNav();
    toggleView('owner');
    showToast("Authenticated as Kitchen Owner. Welcome!", "success");
  } else {
    document.getElementById('loginErrorMsg').classList.remove('hidden');
  }
}

function logoutOwner() {
  isOwnerLoggedIn = false;
  localStorage.removeItem('kt_owner_auth');
  renderAuthNav();
  toggleView('customer');
  showToast("Logged out from Owner Desk.", "info");
}

// CUSTOMER MENU DISPLAY
function renderCustomerMenu(category) {
  const listEl = document.getElementById('customerMenuList');
  if (!listEl) return;

  const items = category === 'all' 
    ? menuData 
    : menuData.filter(item => item.category === category);

  if (items.length === 0) {
    listEl.innerHTML = `<div class="col-span-full py-12 text-center text-stone-500 text-sm">No items found for this selection.</div>`;
    return;
  }

  listEl.innerHTML = items.map(dish => `
    <div class="dish-card bg-white rounded-3xl border border-amber-200/80 overflow-hidden shadow-sm flex flex-col justify-between">
      <div>
        <div class="relative h-48 overflow-hidden bg-amber-100">
          <img src="${dish.image}" alt="${dish.name}" class="w-full h-full object-cover transition-transform duration-500 hover:scale-110">
          
          <div class="absolute top-3 left-3 flex flex-col gap-1">
            <span class="bg-amber-950/80 backdrop-blur-md text-amber-200 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
              ${dish.region}
            </span>
            ${dish.special ? `<span class="bg-rose-700 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-sm">Chef's Special</span>` : ''}
          </div>

          ${!dish.available ? `
            <div class="absolute inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center">
              <span class="bg-rose-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">Sold Out Today</span>
            </div>
          ` : ''}
        </div>

        <div class="p-5">
          <div class="flex items-center justify-between gap-2 mb-1.5">
            <h3 class="font-bold font-serif text-lg text-amber-950">${dish.name}</h3>
            <span class="text-amber-700 font-extrabold text-base">₹${dish.price}</span>
          </div>
          <p class="text-xs text-stone-600 line-clamp-2 leading-relaxed">${dish.description}</p>
        </div>
      </div>

      <div class="p-5 pt-0">
        <button onclick="startSingleSubscription(${dish.id})" ${!dish.available ? 'disabled' : ''} class="w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${dish.available ? 'bg-amber-100/80 hover:bg-amber-700 text-amber-950 hover:text-white' : 'bg-stone-100 text-stone-400 cursor-not-allowed'}">
          <i class="fa-solid fa-bowl-rice"></i>
          <span>Add to Daily Tiffin Box</span>
        </button>
      </div>
    </div>
  `).join('');
}

function setupCategoryFilters() {
  const buttons = document.querySelectorAll('.menu-filter');
  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderCustomerMenu(btn.getAttribute('data-cat'));
    });
  });
}

// CUSTOMER SUBSCRIPTION PLANS
function renderCustomerPlans() {
  const container = document.getElementById('subscriptionPlansContainer');
  if (!container) return;

  container.innerHTML = planData.map((plan, index) => {
    const isFeatured = index === 1;
    return `
      <div class="relative bg-white rounded-3xl p-8 border ${isFeatured ? 'border-2 border-amber-600 shadow-2xl scale-105 z-10' : 'border-amber-200/80 shadow-md'} flex flex-col justify-between">
        ${isFeatured ? `
          <div class="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-700 text-white text-xs font-bold uppercase tracking-wider px-4 py-1 rounded-full shadow-md">
            Most Chosen Plan
          </div>
        ` : ''}

        <div>
          <span class="text-xs font-bold uppercase tracking-wider text-amber-700">${plan.badge}</span>
          <h3 class="text-2xl font-serif font-bold text-amber-950 mt-1">${plan.name}</h3>
          <p class="text-xs text-stone-500 font-medium">${plan.duration} &bull; ${plan.meals} Meals Total</p>

          <div class="my-6 pb-6 border-b border-stone-100">
            <div class="flex items-baseline gap-1">
              <span class="text-4xl font-extrabold text-amber-950 font-serif">₹${plan.price}</span>
              <span class="text-xs text-stone-500 font-medium">/ billing cycle</span>
            </div>
            <p class="text-xs text-emerald-700 font-semibold mt-1">₹${plan.perMeal} per wholesome meal</p>
          </div>

          <ul class="space-y-3 mb-8 text-xs text-stone-600">
            ${plan.features.map(f => `
              <li class="flex items-center gap-2.5">
                <i class="fa-solid fa-circle-check text-emerald-600"></i>
                <span>${f}</span>
              </li>
            `).join('')}
          </ul>
        </div>

        <button onclick="initiateCheckout('${plan.id}')" class="w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition ${isFeatured ? 'bg-amber-700 hover:bg-amber-800 text-white shadow-lg shadow-amber-700/25' : 'bg-amber-100 hover:bg-amber-200 text-amber-950'}">
          Subscribe Now &rarr;
        </button>
      </div>
    `;
  }).join('');
}

// REAL CHECKOUT FLOW
function initiateCheckout(planId) {
  const plan = planData.find(p => p.id === planId);
  if (!plan) return;

  currentSelectedPlan = plan;
  document.getElementById('checkoutPlanBadge').innerText = plan.badge;
  document.getElementById('checkoutPlanName').innerText = `${plan.name} (${plan.duration})`;
  document.getElementById('checkoutAmountDisplay').innerText = `₹${plan.price}`;

  openModal('checkoutModal');
}

function startSingleSubscription(dishId) {
  const dish = menuData.find(d => d.id === dishId);
  if (!dish) return;

  currentSelectedPlan = {
    id: `dish-${dish.id}`,
    name: `Daily Tiffin: ${dish.name}`,
    duration: "7 Days Renewable",
    price: dish.price * 7,
    meals: 7
  };

  document.getElementById('checkoutPlanBadge').innerText = "Direct Kitchen Dish Pass";
  document.getElementById('checkoutPlanName').innerText = `7-Day ${dish.name} Subscription`;
  document.getElementById('checkoutAmountDisplay').innerText = `₹${dish.price * 7}`;

  openModal('checkoutModal');
}

function setPaymentMethod(method) {
  currentPaymentMethod = method;
  document.querySelectorAll('.pm-tab').forEach(b => b.classList.remove('active'));
  document.getElementById(`pm-${method}`).classList.add('active');

  const upiBox = document.getElementById('upiPaymentBox');
  const cardBox = document.getElementById('cardPaymentBox');

  if (method === 'upi') {
    upiBox.classList.remove('hidden');
    cardBox.classList.add('hidden');
  } else if (method === 'card') {
    upiBox.classList.add('hidden');
    cardBox.classList.remove('hidden');
  } else {
    upiBox.classList.add('hidden');
    cardBox.classList.add('hidden');
  }
}

function copyUpiId() {
  navigator.clipboard.writeText("karunadu.foods@okaxis");
  showToast("Merchant UPI ID copied to clipboard!", "success");
}

function processRealPayment(event) {
  event.preventDefault();
  const name = document.getElementById('custName').value.trim();
  const phone = document.getElementById('custPhone').value.trim();
  const address = document.getElementById('custAddress').value.trim();

  const payBtn = document.getElementById('paySubmitBtn');
  payBtn.disabled = true;
  payBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Confirming with Bank...`;

  setTimeout(() => {
    // Register active subscriber
    const newSubscriber = {
      id: Math.floor(100 + Math.random() * 900),
      name: name,
      plan: currentSelectedPlan.name,
      address: address,
      slot: "Midday Oota (12:30 PM)",
      status: "Active"
    };

    subscriberData.unshift(newSubscriber);
    localStorage.setItem('kt_subscribers', JSON.stringify(subscriberData));

    // Update remaining credits
    const walletEl = document.getElementById('walletCredits');
    if (walletEl) {
      walletEl.innerText = parseInt(walletEl.innerText || 18) + (currentSelectedPlan.meals || 6);
    }

    payBtn.disabled = false;
    payBtn.innerHTML = `<i class="fa-solid fa-lock"></i><span>Pay Securely & Activate Plan</span>`;
    closeModal('checkoutModal');

    showToast(`Payment of ₹${currentSelectedPlan.price} received! Your tiffin starts tomorrow.`, "success");
    document.getElementById('paymentForm').reset();
  }, 1400);
}

// SUBSCRIBER SELF-SERVICE
function changeDeliverySlot(slot) {
  showToast(`Delivery slot updated for upcoming orders!`, "info");
}

function togglePauseMeal() {
  const btn = document.getElementById('togglePauseBtn');
  isMealPaused = !isMealPaused;

  if (isMealPaused) {
    btn.classList.replace('bg-amber-700', 'bg-rose-700');
    btn.classList.replace('hover:bg-amber-800', 'hover:bg-rose-800');
    btn.innerText = "Meal Paused for Tomorrow (Tap to Resume)";
    showToast("Tomorrow's tiffin paused. Rollover day added to wallet!", "info");
  } else {
    btn.classList.replace('bg-rose-700', 'bg-amber-700');
    btn.classList.replace('hover:bg-rose-800', 'hover:bg-amber-800');
    btn.innerText = "Pause Meal for Tomorrow";
    showToast("Tiffin resumed for tomorrow's dispatch.", "success");
  }
}

// OWNER BACKOFFICE MANAGEMENT
function switchOwnerTab(tabId) {
  document.querySelectorAll('.owner-subtab').forEach(t => t.classList.add('hidden'));
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.classList.remove('active', 'border-amber-700', 'text-amber-900');
    b.classList.add('border-transparent', 'text-stone-500');
  });

  document.getElementById(tabId).classList.remove('hidden');
  const activeBtn = document.getElementById(tabId === 'menuTab' ? 'btnTabMenu' : tabId === 'manifestTab' ? 'btnTabManifest' : 'btnTabPricing');
  activeBtn.classList.add('active', 'border-amber-700', 'text-amber-900');
  activeBtn.classList.remove('border-transparent', 'text-stone-500');
}

function refreshOwnerDashboard() {
  document.getElementById('statSubCount').innerText = subscriberData.length;
  document.getElementById('statItemCount').innerText = `${menuData.length} Items`;
  renderOwnerMenuTable();
  renderSubscriberTable();
  renderOwnerPlanEditors();
}

function renderOwnerMenuTable() {
  const tbody = document.getElementById('ownerMenuTableBody');
  if (!tbody) return;

  tbody.innerHTML = menuData.map(dish => `
    <tr class="hover:bg-amber-50/50">
      <td class="p-4">
        <div class="flex items-center gap-3">
          <img src="${dish.image}" alt="${dish.name}" class="w-12 h-12 rounded-xl object-cover border border-amber-200">
          <div>
            <div class="font-bold text-stone-900 text-xs">${dish.name}</div>
            <div class="text-[11px] text-stone-500 line-clamp-1">${dish.description}</div>
          </div>
        </div>
      </td>
      <td class="p-4 text-xs font-semibold text-stone-600">${dish.region}</td>
      <td class="p-4">
        <span class="text-[11px] font-bold uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-800">${dish.category}</span>
      </td>
      <td class="p-4 font-bold text-amber-950 text-xs">₹${dish.price}</td>
      <td class="p-4">
        <button onclick="toggleDishAvailability(${dish.id})" class="px-2.5 py-1 rounded-full text-[11px] font-bold transition ${dish.available ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
          ${dish.available ? '● Available' : '○ Disabled'}
        </button>
      </td>
      <td class="p-4 text-right space-x-2">
        <button onclick="openEditDishModal(${dish.id})" class="p-2 text-stone-600 hover:text-amber-700"><i class="fa-solid fa-pen-to-square"></i></button>
        <button onclick="deleteDishItem(${dish.id})" class="p-2 text-stone-400 hover:text-rose-600"><i class="fa-solid fa-trash-can"></i></button>
      </td>
    </tr>
  `).join('');
}

function renderSubscriberTable() {
  const tbody = document.getElementById('subscriberTableBody');
  if (!tbody) return;

  tbody.innerHTML = subscriberData.map(sub => `
    <tr class="hover:bg-amber-50/50">
      <td class="p-4 font-bold text-xs text-stone-900">#${sub.id} - ${sub.name}</td>
      <td class="p-4 text-xs text-amber-800 font-semibold">${sub.plan}</td>
      <td class="p-4 text-xs text-stone-600 max-w-xs truncate">${sub.address}</td>
      <td class="p-4 text-xs font-medium text-stone-500">${sub.slot}</td>
      <td class="p-4">
        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${sub.status === 'Active' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
          ${sub.status}
        </span>
      </td>
      <td class="p-4 text-right">
        <button onclick="toggleSubscriberStatus(${sub.id})" class="text-xs text-stone-500 hover:text-amber-800 font-bold underline">
          ${sub.status === 'Active' ? 'Mark Pause' : 'Mark Active'}
        </button>
      </td>
    </tr>
  `).join('');
}

function renderOwnerPlanEditors() {
  const container = document.getElementById('ownerPricingList');
  if (!container) return;

  container.innerHTML = planData.map(plan => `
    <div class="bg-white p-5 rounded-2xl border border-amber-200 shadow-sm space-y-4">
      <div class="flex justify-between items-center">
        <h4 class="font-bold text-stone-900 text-sm font-serif">${plan.name}</h4>
        <span class="text-xs font-mono bg-amber-100 text-amber-900 px-2 py-0.5 rounded">${plan.duration}</span>
      </div>

      <div>
        <label class="block text-[11px] font-bold text-stone-500 mb-1">Total Plan Price (₹)</label>
        <input type="number" value="${plan.price}" onchange="updatePlanPrice('${plan.id}', this.value)" class="w-full text-xs font-bold p-2 rounded-xl border border-stone-300">
      </div>

      <div>
        <label class="block text-[11px] font-bold text-stone-500 mb-1">Per Meal Value (₹)</label>
        <input type="number" value="${plan.perMeal}" onchange="updatePerMealPrice('${plan.id}', this.value)" class="w-full text-xs p-2 rounded-xl border border-stone-300">
      </div>
    </div>
  `).join('');
}

function updatePlanPrice(planId, newPrice) {
  const p = planData.find(plan => plan.id === planId);
  if (p) {
    p.price = parseInt(newPrice) || p.price;
    localStorage.setItem('kt_plans', JSON.stringify(planData));
    renderCustomerPlans();
    showToast(`Updated price for ${p.name}`, "success");
  }
}

function updatePerMealPrice(planId, newPrice) {
  const p = planData.find(plan => plan.id === planId);
  if (p) {
    p.perMeal = parseInt(newPrice) || p.perMeal;
    localStorage.setItem('kt_plans', JSON.stringify(planData));
    renderCustomerPlans();
  }
}

// Add/Edit Dish Operations
function openAddDishModal() {
  document.getElementById('dishModalTitle').innerText = "Add South Karnataka Dish";
  document.getElementById('dishForm').reset();
  document.getElementById('dishEditId').value = "";
  openModal('dishModal');
}

function openEditDishModal(dishId) {
  const dish = menuData.find(d => d.id === dishId);
  if (!dish) return;

  document.getElementById('dishModalTitle').innerText = "Edit Menu Item";
  document.getElementById('dishEditId').value = dish.id;
  document.getElementById('dishName').value = dish.name;
  document.getElementById('dishRegion').value = dish.region;
  document.getElementById('dishCategory').value = dish.category;
  document.getElementById('dishPrice').value = dish.price;
  document.getElementById('dishImage').value = dish.image;
  document.getElementById('dishDescription').value = dish.description;
  document.getElementById('dishAvailable').checked = dish.available;
  document.getElementById('dishSpecial').checked = dish.special;

  openModal('dishModal');
}

function saveDishItem(event) {
  event.preventDefault();
  const editId = document.getElementById('dishEditId').value;
  const name = document.getElementById('dishName').value.trim();
  const region = document.getElementById('dishRegion').value.trim();
  const category = document.getElementById('dishCategory').value;
  const price = parseInt(document.getElementById('dishPrice').value);
  const image = document.getElementById('dishImage').value.trim() || "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&auto=format&fit=crop&q=80";
  const desc = document.getElementById('dishDescription').value.trim();
  const available = document.getElementById('dishAvailable').checked;
  const special = document.getElementById('dishSpecial').checked;

  if (editId) {
    const dish = menuData.find(d => d.id === parseInt(editId));
    if (dish) {
      Object.assign(dish, { name, region, category, price, image, description: desc, available, special });
      showToast("Dish details updated!", "success");
    }
  } else {
    const newDish = {
      id: Date.now(),
      name, region, category, price, image, description: desc, available, special
    };
    menuData.unshift(newDish);
    showToast("New dish added to kitchen catalog!", "success");
  }

  localStorage.setItem('kt_menu', JSON.stringify(menuData));
  closeModal('dishModal');
  renderCustomerMenu('all');
  refreshOwnerDashboard();
}

function toggleDishAvailability(dishId) {
  const dish = menuData.find(d => d.id === dishId);
  if (dish) {
    dish.available = !dish.available;
    localStorage.setItem('kt_menu', JSON.stringify(menuData));
    renderOwnerMenuTable();
    renderCustomerMenu('all');
    showToast(`Updated availability for ${dish.name}`, "info");
  }
}

function deleteDishItem(dishId) {
  if (confirm("Are you sure you want to remove this dish from the menu?")) {
    menuData = menuData.filter(d => d.id !== dishId);
    localStorage.setItem('kt_menu', JSON.stringify(menuData));
    renderOwnerMenuTable();
    renderCustomerMenu('all');
    showToast("Dish deleted from database.", "info");
  }
}

function toggleSubscriberStatus(subId) {
  const sub = subscriberData.find(s => s.id === subId);
  if (sub) {
    sub.status = sub.status === 'Active' ? 'Paused Today' : 'Active';
    localStorage.setItem('kt_subscribers', JSON.stringify(subscriberData));
    renderSubscriberTable();
  }
}

// CSV EXPORT FOR KITCHEN PACKING
function exportSubscribersCSV() {
  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "Subscriber ID,Customer Name,Subscribed Plan,Delivery Area & Address,Time Slot,Kitchen Dispatch Status\n";

  subscriberData.forEach(s => {
    const row = [
      `#${s.id}`,
      `"${s.name}"`,
      `"${s.plan}"`,
      `"${s.address}"`,
      `"${s.slot}"`,
      `"${s.status}"`
    ].join(",");
    csvContent += row + "\n";
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `karunadu_dispatch_manifest_${new Date().toISOString().slice(0,10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast("Kitchen Delivery CSV exported successfully!", "success");
}

// Toast Notifier
function showToast(msg, type = "info") {
  const toast = document.getElementById('toast');
  const toastMsg = document.getElementById('toastMsg');
  const toastIcon = document.getElementById('toastIcon');

  toastMsg.innerText = msg;
  if (type === 'success') {
    toastIcon.className = "fa-solid fa-circle-check text-emerald-400 text-base";
  } else if (type === 'error') {
    toastIcon.className = "fa-solid fa-circle-xmark text-rose-400 text-base";
  } else {
    toastIcon.className = "fa-solid fa-circle-info text-amber-400 text-base";
  }

  toast.classList.remove('translate-y-24', 'opacity-0');
  setTimeout(() => {
    toast.classList.add('translate-y-24', 'opacity-0');
  }, 3500);
}
